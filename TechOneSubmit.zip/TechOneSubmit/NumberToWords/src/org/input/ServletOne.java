package org.input;
import java.io.IOException;
import java.math.BigInteger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet class to incorporate the functionality of a web page.
 * Uses tomcat server v7.0. 
 * @author sampadasakpal
 *
 */
@WebServlet(name="servletone", urlPatterns={"/servletone"})
public class ServletOne extends HttpServlet {
	
	/**
	 * Method overridden from abstract class HttpServlet. Used to access
	 * form parameters with values inputted by the customer. 
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		/* The number specified by the customer*/
		String rawNumber = request.getParameter("number");
		
		
		/* HTML code for the corresponding webpage that is to be displayed
		 * after the customer clicks the submit button */
		String htmlCode = "<!DOCTYPE html><html>";
		htmlCode += "<head>";
		htmlCode += "<title> Number in Words </title>";
		htmlCode += "<style> ";
		htmlCode += "h1 { background-color: slategrey; "
				+ "color: snow;"
				+ "text-align: center;"
				+ "font-family: georgia;"
				+ "font-size: 40px; }";
		
		htmlCode += "body { background-color: oldlace;"
				+ "color: lightslategrey;"
				+ "font-family: georgia;"
				+ "font-size: 18px;}";
		htmlCode += "</style>";
		htmlCode += "</head>";
		String words;
		try {
			/* in the case that the customer only clicks on submit, without
			 * specifying a number */
			if(rawNumber.length() == 0) {
				htmlCode += "<body> No number has been entered. "
						+ "Please try again. </body>";
				
			}
			else {
				ConvertToWords cv = new ConvertToWords(rawNumber);
				
				/* the current program
				 * only allows customers to input numbers with 2 digits 
				 * after the decimal point*/
				if(cv.getSizeOfFractionPart() > 2) {
					htmlCode += "<body> Number is not specified to 2 "
							+ "decimal places. Please try again. </body>";
				}
				else {
					cv.buildWord();
					words = cv.getWord();
					htmlCode += "<h1> The number you entered is equivalent to...</h1>";
					htmlCode += "<body>" + words + "</body>";
				}
				
			}
			
		}
		catch( Exception e) {
			/* in the case, that the input specified by the customer is 
			 * not a number or has special characters (not incl. period (.))*/
			htmlCode += "<body> Error, the number entered: "+ rawNumber+"<br>"
					+ " is invalid."
					+ " Please try again!</body>";
			
		}
		
		htmlCode += "</html>";
		
		response.getWriter().println(htmlCode);

	}

	

}
