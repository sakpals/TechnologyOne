package org.input;

/**
 * ConvertToWords class contains the necessary methods needed to convert an input
 * from the client to words (in terms of dollars and cents)
 * @author sampadasakpal
 *
 */
public class ConvertToWords {
	
	/**
	 * string components of the input typed by customer 
	 */
	private String integerPart = "";
	private String fractionPart = "";
	
	/**
	 * sizes of each string component 
	 */
	private int sizeOfIntegerPart = 0;
	private int sizeOfFractionPart = 0;
	
	/**
	 * arrays specifying the word equivalent of a particular number in the context
	 * of its position within the number 
	 */
	private String[] ones = {" ZERO ", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", 
			"SEVEN", "EIGHT", "NINE"};
	
	private String[] others = {"TEN","ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN",
			"FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN"};
	
	private String[] tens = {others[0], "TWENTY", "THIRTY", "FORTY", "FIFTY",
			"SIXTY", "SEVENTY", "EIGHTY", "NINETY"};
	
	private String[] placeValues = {"HUNDRED", "THOUSAND",
			"MILLION", "BILLION", "TRILLION"};
	
	/**
	 * the converted number to word to be displayed 
	 */
	private String word ="";
	
	/**
	 * Constructor for the class. Initilaises the integer and fraction parts of
	 * the string input specified by the customer, by splitting the string 
	 * (if necessary) at the decimal point.
	 * @param input
	 */
	public ConvertToWords(String input) {
		if(input.contains(".")) {
			
			String[] number = input.split("\\.");
			
			/* in the case where only numbers after the decimal point are specified */
			if(number[0].equals("")) {
				integerPart = "0";
			}else {
				/* get rid of any leading zeros */
				integerPart =  Integer.toString(Integer.parseInt(number[0]));
			}
			fractionPart = number[1];
			
		}
		else {
			/* get rid of any leading zeros */
			input = Integer.toString(Integer.parseInt(input));
			integerPart = input;
		}
		sizeOfIntegerPart = integerPart.length();
		sizeOfFractionPart = fractionPart.length();
	}
	
	/**
	 * Builds the final word equivalent to the number inputted by the customer
	 * in terms of dollars and cents.
	 */
	public void buildWord () {
		String cents = buildFractionPart();
		String dollars = buildIntegerPart();
		word += dollars+ " DOLLARS AND " + cents + " CENTS";
	}
	
	/**
	 * Builds the integer (dollars) part of the word.
	 * @return number of dollars expressed in words
	 */
	public String buildIntegerPart() {
		/* word representing the integer part */
		String integerWord = "";
		
		/* the current section of the integer part to be analysed and converted */
		String currentSection = "";
	
		/*  inspects the integer part from input in groups of 1,2 or 3 digits, until
		 * the string, integerPart is empty */
		while(sizeOfIntegerPart > 0) {
			
			/* if the number cannot be divided into equal groups of three digits, 
			 * then look at the first group of 1 or 2 most significant digits 
			 * i.e 4,123 --> look at 4
			 * 43,432 --> look at 43 */
			if(sizeOfIntegerPart%3 != 0) {	
				currentSection = integerPart.substring(0,sizeOfIntegerPart%3);
				
				integerWord += buildSectionPart(currentSection);
				if(sizeOfIntegerPart >= 3) {
					integerWord += " "+ placeValues[sizeOfIntegerPart/3]+" ";
				}
			}
			
			/* if the number can be divided into equal groups of three digits, then look
			 * at the first group of 3 digits starting from the most significant digit  */
			else {
				currentSection = integerPart.substring(0,3);
				integerWord += buildSectionPart(currentSection);
				if(sizeOfIntegerPart != 3) {
					integerWord += " "+ placeValues[sizeOfIntegerPart/3 -1]+ " ";
				}
			}
			/* cut of the part of integerPart string that has been analysed and 
			 * converted into words*/
			integerPart = integerPart.substring(currentSection.length());
			sizeOfIntegerPart = integerPart.length();
			
		}
		return integerWord;
	}
	
	/**
	 * Builds the word equivalent of the section part of a 1,2 or 3 digit number 
	 * @param currentSection the 1,2 or 3 digit number being analysed
	 * @return the word equivalent of currentSection
	 */
	private String buildSectionPart(String currentSection) {
		String sectionWord = "";
		
		
		/* when there are 3 digits */
		if(currentSection.length() > 2) {
			sectionWord += ones[Integer.parseInt("0"+currentSection.charAt(0))] + 
					 " " +placeValues[0] + " AND ";
			if(currentSection.charAt(1) == '1') {
				sectionWord += others[Integer.parseInt(currentSection.substring(1,3))-10];
			}
			else {
				if(currentSection.charAt(1) != '0') {
					sectionWord += tens[Integer.parseInt("0"+currentSection.charAt(1)) -1] + "-";
				}
				sectionWord += ones[Integer.parseInt("0"+currentSection.charAt(2))];
			}
		}
		/* when there are 2 digits  */
		else if(currentSection.length() > 1){
			if(currentSection.charAt(0) == '1') {
				sectionWord += others[Integer.parseInt(currentSection.substring(0,2))-10];
			}
			else {
				if(currentSection.charAt(1) != '0') {
					sectionWord += tens[Integer.parseInt("0"+currentSection.charAt(0)) -1] + "-";
				}
				sectionWord += ones[Integer.parseInt("0"+currentSection.charAt(1))];
			}
		}
		/* when there is only 1 digit */
		else if(currentSection.length() > 0) {
			if(currentSection.charAt(0) == '0') {
				sectionWord += ones[0];
			}
			else {
				sectionWord += ones[Integer.parseInt("0"+currentSection.charAt(0))];
			}	
		}
		else {
			sectionWord += ones[0];
		}
		return sectionWord;
	}

	/**
	 * Builds the fraction (cents) part of the word
	 * @return number of cents in words
	 */
	public String buildFractionPart() {
		String fractionWord = "";
		fractionWord = buildSectionPart(fractionPart);
		return fractionWord;
	}

	/**
	 * Public accessor method for the variable sizeOfFractionPart
	 * @return sizeOfFractionPart
	 */
	public int getSizeOfFractionPart() {
		return sizeOfFractionPart;
	}
	/**
	 * Public accessor method for the variable word
	 * @return word
	 */
	public String getWord() {
		return word;
	}
	
}
